const ShopActionTypes = {
    UPDATE_COLLECTIONS: 'UPDATE_COLLECTIONS'
}


export default ShopActionTypes